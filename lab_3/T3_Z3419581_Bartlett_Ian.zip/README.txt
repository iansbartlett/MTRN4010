Ian Bartlett, z3419581

All programs should be ready to run. The code will expect the data files to be stored in a folder called DataForProject02, containing the .mat files for laser, encoder speed, and IMU data. 
